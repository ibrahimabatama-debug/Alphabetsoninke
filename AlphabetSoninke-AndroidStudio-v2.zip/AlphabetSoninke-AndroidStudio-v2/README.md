# Alphabet Soninké – Android Studio v2

Cette version intègre les 26 lettres et les 26 mots fournis par l'utilisateur.

## Alphabet et mots

A — Arina ni wo di
B — Banne
C — Ceero
D — Daaru
E — Eyiwa
F — Fanke
G — Gede
H — Haami
I — I ti inta riini
J — Jaarabu
K — kilometara
L — Lenki
M — maama
N — Na
Ñ — Ñage
Ŋ — Ŋada
O — O ka hi
P — Paala
Q — Laqe
R — Raga
S — Sansa
T — Teriike
U — Uuri
W — Waara
X — Xaase
Y — yaadante

## Fonctions

- Affichage de la lettre en grand
- Affichage du mot Soninké
- Boutons Précédent / Suivant
- Compteur 1 / 26
- Bouton Écouter
- Structure prête pour les vrais enregistrements audio Soninké
- Si un audio n'est pas encore ajouté, l'application utilise temporairement la synthèse vocale comme secours

## Ajouter les audios

Copier les fichiers MP3 dans :

app/src/main/res/raw/

en utilisant les noms indiqués dans `app/src/main/res/raw/README_AUDIO.txt`.

Exemple :
`audio_a.mp3` pour A → Arina ni wo di.

Après ajout d'un audio, Android Studio le détectera automatiquement et le bouton
« Écouter » utilisera cet enregistrement.

## Ouvrir

1. Décompresser le ZIP.
2. Ouvrir le dossier dans Android Studio.
3. Laisser Android Studio synchroniser Gradle.
4. Brancher un téléphone Android ou utiliser un émulateur.
5. Lancer l'application.

## Version

2.0
