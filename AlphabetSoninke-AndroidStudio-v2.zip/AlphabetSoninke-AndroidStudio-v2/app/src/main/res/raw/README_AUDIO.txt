DOSSIER DES AUDIOS

Ajoutez les enregistrements Soninké dans app/src/main/res/raw/.

Noms attendus :
audio_a.mp3
audio_b.mp3
audio_c.mp3
audio_d.mp3
audio_e.mp3
audio_f.mp3
audio_g.mp3
audio_h.mp3
audio_i.mp3
audio_j.mp3
audio_k.mp3
audio_l.mp3
audio_m.mp3
audio_n.mp3
audio_nya.mp3
audio_eng.mp3
audio_o.mp3
audio_p.mp3
audio_q.mp3
audio_r.mp3
audio_s.mp3
audio_t.mp3
audio_u.mp3
audio_w.mp3
audio_x.mp3
audio_y.mp3

Les fichiers peuvent être ajoutés progressivement. L'application fonctionne
même si les audios ne sont pas encore présents.
