package com.alphasoninke.app

import android.media.MediaPlayer
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

data class LetterItem(
    val letter: String,
    val word: String,
    val audioResName: String
)

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private val items = listOf(
        LetterItem("A", "Arina ni wo di", "audio_a"),
        LetterItem("B", "Banne", "audio_b"),
        LetterItem("C", "Ceero", "audio_c"),
        LetterItem("D", "Daaru", "audio_d"),
        LetterItem("E", "Eyiwa", "audio_e"),
        LetterItem("F", "Fanke", "audio_f"),
        LetterItem("G", "Gede", "audio_g"),
        LetterItem("H", "Haami", "audio_h"),
        LetterItem("I", "I ti inta riini", "audio_i"),
        LetterItem("J", "Jaarabu", "audio_j"),
        LetterItem("K", "kilometara", "audio_k"),
        LetterItem("L", "Lenki", "audio_l"),
        LetterItem("M", "maama", "audio_m"),
        LetterItem("N", "Na", "audio_n"),
        LetterItem("Ñ", "Ñage", "audio_nya"),
        LetterItem("Ŋ", "Ŋada", "audio_eng"),
        LetterItem("O", "O ka hi", "audio_o"),
        LetterItem("P", "Paala", "audio_p"),
        LetterItem("Q", "Laqe", "audio_q"),
        LetterItem("R", "Raga", "audio_r"),
        LetterItem("S", "Sansa", "audio_s"),
        LetterItem("T", "Teriike", "audio_t"),
        LetterItem("U", "Uuri", "audio_u"),
        LetterItem("W", "Waara", "audio_w"),
        LetterItem("X", "Xaase", "audio_x"),
        LetterItem("Y", "yaadante", "audio_y")
    )

    private var index = 0
    private var mediaPlayer: MediaPlayer? = null
    private lateinit var letterView: TextView
    private lateinit var wordView: TextView
    private lateinit var progressView: TextView
    private lateinit var audioButton: Button
    private lateinit var tts: TextToSpeech

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        showItem()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
        }

        val title = TextView(this).apply {
            text = "Alphabet Soninké"
            textSize = 28f
            gravity = Gravity.CENTER
        }

        progressView = TextView(this).apply {
            textSize = 18f
            gravity = Gravity.CENTER
        }

        letterView = TextView(this).apply {
            textSize = 88f
            gravity = Gravity.CENTER
            setPadding(0, 30, 0, 10)
        }

        wordView = TextView(this).apply {
            textSize = 28f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 24)
        }

        audioButton = Button(this).apply {
            text = "🔊 Écouter"
            textSize = 18f
            setOnClickListener { playAudioOrPrepare() }
        }

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        val previous = Button(this).apply {
            text = "← Précédent"
            setOnClickListener {
                if (index > 0) {
                    index--
                    showItem()
                }
            }
        }

        val next = Button(this).apply {
            text = "Suivant →"
            setOnClickListener {
                if (index < items.lastIndex) {
                    index++
                    showItem()
                }
            }
        }

        nav.addView(previous, LinearLayout.LayoutParams(0, -2, 1f))
        nav.addView(next, LinearLayout.LayoutParams(0, -2, 1f))

        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        root.addView(progressView, LinearLayout.LayoutParams(-1, -2))
        root.addView(letterView, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(wordView, LinearLayout.LayoutParams(-1, -2))
        root.addView(audioButton, LinearLayout.LayoutParams(-1, -2))
        root.addView(nav, LinearLayout.LayoutParams(-1, -2))

        setContentView(root)
    }

    private fun showItem() {
        val item = items[index]
        letterView.text = item.letter
        wordView.text = item.word
        progressView.text = "${index + 1} / ${items.size}"
        audioButton.text = "🔊 Écouter"

        val audioId = resources.getIdentifier(item.audioResName, "raw", packageName)
        audioButton.isEnabled = true
        audioButton.alpha = if (audioId != 0) 1f else 0.65f
    }

    private fun playAudioOrPrepare() {
        val item = items[index]
        val audioId = resources.getIdentifier(item.audioResName, "raw", packageName)

        if (audioId != 0) {
            mediaPlayer?.release()
            mediaPlayer = MediaPlayer.create(this, audioId)
            mediaPlayer?.setOnCompletionListener { it.release() }
            mediaPlayer?.start()
        } else {
            // En attendant l'enregistrement Soninké, on utilise la synthèse vocale
            // uniquement comme solution de secours.
            if (::tts.isInitialized) {
                tts.language = Locale.FRENCH
                tts.speak(item.word, TextToSpeech.QUEUE_FLUSH, null, "soninke_${item.letter}")
                Toast.makeText(this, "Audio Soninké à ajouter plus tard", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onInit(status: Int) {
        // La synthèse vocale est seulement un secours.
    }

    override fun onDestroy() {
        mediaPlayer?.release()
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        super.onDestroy()
    }
}
